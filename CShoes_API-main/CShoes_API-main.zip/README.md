# SolePalette API

#### Run npm run dev

#### Run Init.sql
